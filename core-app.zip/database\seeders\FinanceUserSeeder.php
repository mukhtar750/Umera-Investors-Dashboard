<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class FinanceUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Finance Manager',
            'email' => 'finance@umera.com',
            'password' => Hash::make('password'),
            'role' => 'finance',
            'email_verified_at' => now(),
        ]);
    }
}
