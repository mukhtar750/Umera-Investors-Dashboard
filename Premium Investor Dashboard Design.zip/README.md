
  # Premium Investor Dashboard Design

  This is a code bundle for Premium Investor Dashboard Design. The original project is available at https://www.figma.com/design/b0SXnw2CLUnQcR16RoXoXH/Premium-Investor-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  